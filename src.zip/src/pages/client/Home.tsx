export function Home() {
  return (
    <div>
        <div style={{height:'500px'}}>

        </div>
    </div>
  )
}